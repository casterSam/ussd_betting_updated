import axios from 'axios';
import * as cheerio from 'cheerio';

// Configuration constants
const SCRAPE_TIMEOUT = 5000;
const LAMBDA_TIMEOUT = 8000;
const CACHE_TTL = 300000; // 5 minutes

// Response templates
const RESPONSES = {
  mainMenu: `CON Today's Football Tips\n1. Show Top 5 Matches\n2. About Service`,
  about: 'CON Betstudy Betting Tips\nOfficial predictions source\n0. Back',
  error: 'END Service error. Try later.',
  timeout: 'END Service timeout. Please try again.',
  invalid: 'END Invalid option.'
};

// Cache implementation
const cache = {
  timestamp: 0,
  data: [],
  get isValid() {
    return Date.now() - this.timestamp < CACHE_TTL && this.data.length > 0;
  }
};

// Timeout handler
const timeoutPromise = (timeout) => 
  new Promise((_, reject) => 
    setTimeout(() => reject(new Error('Timeout')), timeout)
  );


export const handler = async (event) => {
  try {
    return await Promise.race([
      mainHandler(event),
      timeoutPromise(LAMBDA_TIMEOUT)
    ]);
  } catch (error) {
    console.error('Handler error:', error.message);
    return errorResponse(error);
  }
};

async function mainHandler(event) {
  const { text = '' } = parseInput(event);
  const lastInput = text.split('*').pop().trim();

  try {
    if (text === '') return textResponse(RESPONSES.mainMenu);
    if (lastInput === '1') return await handlePredictions();
    if (lastInput === '2') return textResponse(RESPONSES.about);
    if (lastInput === '0') return textResponse(RESPONSES.mainMenu);
    return textResponse(RESPONSES.invalid);
  } catch (error) {
    console.error('Processing error:', error);
    return textResponse(RESPONSES.error);
  }
}

async function handlePredictions() {
  const tips = await scrapeBetstudyPredictions();
  
  if (tips.length === 0) {
    return textResponse(RESPONSES.error);
  }

  const formattedTips = tips
    .slice(0, 5)
    .map((tip, index) => 
      `${index + 1}. ${tip.match}\nTime: ${tip.time}\nTip: ${tip.tip} (${tip.odds})`
    )
    .join('\n\n');

  return textResponse(`CON Today's Top Matches:\n${formattedTips}\n0. Back`);
}

async function scrapeBetstudyPredictions() {
  if (cache.isValid) return cache.data;

  try {
    const response = await axios.get('https://www.betstudy.com/predictions/', {
      timeout: SCRAPE_TIMEOUT,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept-Language': 'en-US,en;q=0.9'
      }
    });

    const $ = cheerio.load(response.data);
    const newData = [];

    $('div.computer-predictions-tbl tr').each((i, el) => {
      if (newData.length >= 5) return false;

      const $row = $(el);
      const time = $row.find('.time span').text().replace(/\s+/g, ' ').trim();
      const match = $row.find('.match a').text().split('\n').slice(0, 2).join(' vs ').trim();
      const tip = $row.find('.predictons.hide-sm').text().trim();
      const odds = $row.find('.betnow a').text().match(/(\d+\.\d+)/)?.[1] || 'N/A';

      if (match && time) {
        newData.push({ time, match, tip, odds });
      }
    });

    cache.data = newData;
    cache.timestamp = Date.now();
    return newData;
  } catch (error) {
    console.error('Scraping error:', error.message);
    return cache.isValid ? cache.data : [];
  }
}

// Helper functions
function parseInput(event) {
  try {
    const params = new URLSearchParams(event.body);
    return { text: params.get('text') || '' };
  } catch (e) {
    return { text: event.body?.text || '' };
  }
}

function textResponse(body) {
  return {
    statusCode: 200,
    headers: { 'Content-Type': 'text/plain' },
    body
  };
}

function errorResponse(error) {
  return {
    statusCode: 200,
    headers: { 'Content-Type': 'text/plain' },
    body: error.message.includes('Timeout') ? RESPONSES.timeout : RESPONSES.error
  };
}